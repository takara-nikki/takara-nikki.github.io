#!/bin/zsh
# 先講話、再響鈴；每次隨機一句。按「關掉」就停
lines=(
  "匯出完成，不要偷懶了喔"
  "叮咚，片子烤好了，趁熱交給客戶吧"
  "匯出完成，老闆在看你喔，快點動起來"
  "報告，影片已經出爐，請不要再滑手機了"
  "恭喜你，又活過了一次算圖，起來伸個懶腰吧"
)
msg=${1:-${lines[$(( RANDOM % ${#lines} + 1 ))]}}
for i in {1..6}; do
  /usr/bin/say -v Meijia -r 185 "$msg" 2>/dev/null
  for j in 1 2; do /usr/bin/afplay -v 0.6 /System/Library/Sounds/Funk.aiff; done
  sleep 1.5
done
