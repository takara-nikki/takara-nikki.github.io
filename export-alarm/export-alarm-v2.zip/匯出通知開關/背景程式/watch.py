#!/usr/bin/python3
# 匯出鬧鐘：偵測 Premiere / Media Encoder 寫完輸出檔後，響小聲鬧鐘＋跳出可按掉的小視窗。
import subprocess, time, os, signal

# 只有影片才響（2026-11-13 改）：字幕 srt/vtt/scc/xml、聲音 wav/mp3/aac/m4a/aif/aiff、gif 都不響
EXTS = ('.mp4', '.mov', '.mxf', '.m4v', '.avi', '.mkv', '.mpg', '.mpeg',
        '.mts', '.m2ts', '.webm')


def is_video(path):
    return path.lower().endswith(EXTS)
SKIP = ('Previews', 'Media Cache', 'Auto-Save', '/Library/Caches', 'Conformed',
        '/var/folders/', '/private/var/')
POLL = 4          # 秒
MIN_WRITE = 8     # 至少寫了幾秒才算匯出（排除暫存小檔）
MIN_SIZE = 512 * 1024
ALARM = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'alarm.sh')
LOG = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'watch.log')


def log(msg):
    try:
        with open(LOG, 'a') as f:
            f.write(time.strftime('%Y-%m-%d %H:%M:%S ') + msg + '\n')
    except Exception:
        pass


def writing_files():
    try:
        out = subprocess.run(['/usr/sbin/lsof', '+c', '0', '-c', 'Adobe Premiere',
                              '-c', 'Adobe Media Encoder', '-F', 'casn'],
                             capture_output=True, timeout=20).stdout
    except Exception:
        return {}
    res = {}
    acc = size = None
    for raw in out.split(b'\n'):
        if not raw:
            continue
        t, v = chr(raw[0]), raw[1:]
        if t == 'f':
            acc = size = None
        elif t == 'a':
            acc = v.decode(errors='ignore')
        elif t == 's':
            try:
                size = int(v)
            except ValueError:
                size = None
        elif t == 'n':
            path = v.decode('utf-8', errors='replace')
            if acc in ('w', 'u') and is_video(path) and not any(s in path for s in SKIP):
                res[path] = size or 0
    return res


def _ring_worker(path):
    # 背景子行程：響鈴＋顯示 Premiere 風格的完成視窗，按「關掉」就停
    import random
    here = os.path.dirname(os.path.abspath(__file__))
    try:
        lines = [l.strip() for l in open(os.path.join(here, 'lines.txt'), encoding='utf-8') if l.strip()]
    except Exception:
        lines = []
    line = random.choice(lines) if lines else '匯出完成'
    p = subprocess.Popen(['/bin/zsh', ALARM, line], start_new_session=True)
    ui = os.path.join(here, 'ExportDone')
    try:
        subprocess.run([ui, path, line], timeout=650)
    except Exception:
        pass
    try:
        os.killpg(p.pid, signal.SIGTERM)
    except Exception:
        pass
    subprocess.run(['/usr/bin/pkill', '-f', 'BaoExportAlarm/alarm.sh'])
    subprocess.run(['/usr/bin/pkill', '-x', 'afplay'])


def ring(path):
    name = os.path.basename(path)
    log('DONE ' + path)
    if os.fork() == 0:
        try:
            os.setsid()
            _ring_worker(path)
        finally:
            os._exit(0)


def main():
    signal.signal(signal.SIGCHLD, signal.SIG_IGN)
    seen = {}   # path -> [first_seen, last_size]
    log('watcher started')
    while True:
        cur = writing_files()
        now = time.time()
        for path, size in cur.items():
            if path in seen:
                seen[path][1] = max(seen[path][1], size)
            else:
                seen[path] = [now, size]
        for path in list(seen):
            if path not in cur:
                first, size = seen.pop(path)
                try:
                    st = os.stat(path)
                    exists, size = True, max(size, st.st_size)
                except PermissionError:
                    exists = True
                except FileNotFoundError:
                    exists = False   # 取消匯出 → 檔案被刪 → 不響
                except Exception:
                    exists = True
                if exists and is_video(path) and now - first >= MIN_WRITE and size >= MIN_SIZE:
                    ring(path)
        time.sleep(POLL)


if __name__ == '__main__':
    main()
