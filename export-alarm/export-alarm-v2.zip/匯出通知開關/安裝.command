#!/bin/zsh
# 匯出通知開關 安裝程式（寶物日誌影像）
cd "${0:A:h}"
D="$HOME/Library/Application Support/BaoExportAlarm"
P="$HOME/Library/LaunchAgents/com.bao.exportalarm.plist"
echo "== 匯出通知開關 安裝中 =="
if [ "$(uname -m)" != "arm64" ]; then echo "抱歉，目前只支援 Apple 晶片（M1 以上）的 Mac"; read; exit 1; fi
if ! /usr/bin/xcode-select -p >/dev/null 2>&1; then
  echo "第一次使用需要 Apple 的「指令列工具」（內含 Python），已跳出安裝視窗，裝完再雙擊一次「安裝」"
  /usr/bin/xcode-select --install; read; exit 0
fi
mkdir -p "$D" "$HOME/Library/LaunchAgents"
cp 背景程式/* "$D/"; chmod +x "$D/alarm.sh" "$D/watch.py" "$D/ExportDone"
xattr -dr com.apple.quarantine "$D" "匯出通知開關.app" 2>/dev/null
cat > "$P" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>Label</key><string>com.bao.exportalarm</string>
<key>ProgramArguments</key><array><string>/usr/bin/python3</string><string>$D/watch.py</string></array>
<key>RunAtLoad</key><true/><key>KeepAlive</key><true/>
<key>StandardErrorPath</key><string>$D/err.log</string>
</dict></plist>
PL
launchctl bootout "gui/$(id -u)/com.bao.exportalarm" 2>/dev/null
launchctl bootstrap "gui/$(id -u)" "$P" && echo "=== 安裝完成，匯出通知已開啟 ==="
rm -rf "/Applications/匯出通知開關.app"; cp -R "匯出通知開關.app" /Applications/ && echo "開關已放到「應用程式」資料夾"
echo; echo "要測試：雙擊「測試鈴聲」；之後 Premiere 匯出完成就會叫你"; echo "可以關掉這個視窗了"
