#!/bin/zsh
launchctl bootout "gui/$(id -u)/com.bao.exportalarm" 2>/dev/null
rm -f "$HOME/Library/LaunchAgents/com.bao.exportalarm.plist"
rm -rf "$HOME/Library/Application Support/BaoExportAlarm" "/Applications/匯出通知開關.app"
echo "已經全部移除，可以關掉這個視窗"
