#!/bin/zsh
D="$HOME/Library/Application Support/BaoExportAlarm"
zsh "$D/alarm.sh" "測試成功，匯出完成會這樣叫你" & A=$!
"$D/ExportDone" "/範例/20261127 測試_Final.mp4" "測試成功，匯出完成會這樣叫你"
kill $A 2>/dev/null; pkill -f BaoExportAlarm/alarm.sh; pkill -x afplay
