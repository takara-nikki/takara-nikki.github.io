// 匯出通知開關：Premiere 風格深色視窗
// 用法：osascript -l JavaScript panel.js <ask|done|fail> <on|off> <Resources資料夾>
ObjC.import('Cocoa');

var choice = 'cancel';

function C(hex) {
  return $.NSColor.colorWithSRGBRedGreenBlueAlpha(
    parseInt(hex.substr(0, 2), 16) / 255,
    parseInt(hex.substr(2, 2), 16) / 255,
    parseInt(hex.substr(4, 2), 16) / 255, 1);
}
function R(x, y, w, h) { return $.NSMakeRect(x, y, w, h); }

function label(text, x, y, w, h, size, color, bold) {
  var t = $.NSTextField.alloc.initWithFrame(R(x, y, w, h));
  t.setStringValue($(text));
  t.setBezeled(false);
  t.setDrawsBackground(false);
  t.setEditable(false);
  t.setSelectable(false);
  t.setTextColor(color);
  t.setFont(bold ? $.NSFont.boldSystemFontOfSize(size) : $.NSFont.systemFontOfSize(size));
  return t;
}

function box(x, y, w, h, color, radius) {
  var b = $.NSBox.alloc.initWithFrame(R(x, y, w, h));
  b.setBoxType(4);            // NSBoxCustom
  b.setBorderWidth(0);
  b.setFillColor(color);
  b.setCornerRadius(radius || 0);
  b.setTitlePosition(0);      // 不顯示標題
  return b;
}

ObjC.registerSubclass({
  name: 'BaoAlarmHandler',
  methods: {
    'clicked:': {
      types: ['void', ['id']],
      implementation: function (sender) {
        var t = sender.tag;
        choice = (t == 1) ? 'off' : (t == 2) ? 'on' : (t == 3) ? 'ok' : 'cancel';
        $.NSApp.stopModal;
      }
    },
    'tick:': {
      types: ['void', ['id']],
      implementation: function (timer) { choice = 'ok'; $.NSApp.stopModal; }
    }
  }
});

function run(argv) {
  var mode = argv[0] || 'ask', state = argv[1] || 'off', res = argv[2] || '.';
  var isOn = (state === 'on');

  $.NSApplication.sharedApplication;
  $.NSApp.setActivationPolicy($.NSApplicationActivationPolicyAccessory);

  var W = 460, H = 196;
  var win = $.NSPanel.alloc.initWithContentRectStyleMaskBackingDefer(
    R(0, 0, W, H), $.NSWindowStyleMaskTitled | $.NSWindowStyleMaskFullSizeContentView,
    $.NSBackingStoreBuffered, false);
  win.setTitle($('匯出通知'));
  win.setTitlebarAppearsTransparent(true);
  win.setTitleVisibility(1);   // 隱藏標題文字
  win.setAppearance($.NSAppearance.appearanceNamed($.NSAppearanceNameDarkAqua));
  win.setBackgroundColor(C('232323'));
  win.setLevel($.NSFloatingWindowLevel);
  var v = win.contentView;
  var handler = $.BaoAlarmHandler.alloc.init;

  // 頂部細色條（Premiere 藍）
  v.addSubview(box(0, H - 3, W, 3, C('2680EB'), 0));

  // 圖示
  var iv = $.NSImageView.alloc.initWithFrame(R(22, H - 30 - 60, 60, 60));
  iv.setImage($.NSImage.alloc.initWithContentsOfFile($(res + '/' + (isOn ? 'on' : 'off') + '.icns')));
  v.addSubview(iv);

  // 標題
  v.addSubview(label('匯出完成鬧鐘', 96, H - 52, 340, 22, 15, C('E6E6E6'), true));

  // 狀態列：色點 + 文字（不用 Emoji）
  var dotColor = isOn ? C('34C759') : C('6E6E73');
  v.addSubview(box(98, H - 72, 9, 9, dotColor, 4.5));
  var statusText, desc;
  if (mode === 'ask') {
    statusText = isOn ? '目前狀態：開啟中' : '目前狀態：關閉中';
    desc = isOn ? 'Premiere／Media Encoder 匯出影片完成時會響鈴。\nSRT 字幕與聲音檔不會響。'
                : '匯出完成時不會提醒你。';
  } else if (mode === 'done') {
    statusText = isOn ? '已開啟' : '已關閉';
    desc = isOn ? '之後匯出影片完成時會響鈴提醒你。' : '之後匯出完成時不會再響了。';
  } else {
    statusText = '切換失敗';
    desc = '狀態沒有改變，請重新打開「安裝.command」。';
    dotColor = C('FF453A');
  }
  v.addSubview(label(statusText, 112, H - 79, 320, 20, 13, isOn ? C('34C759') : C('B0B0B5'), true));
  v.addSubview(label(desc, 96, 70, 350, 38, 12, C('9A9A9E'), false));

  // 分隔線 + 底部按鈕區
  v.addSubview(box(0, 56, W, 1, C('3A3A3C'), 0));
  v.addSubview(box(0, 0, W, 56, C('1C1C1E'), 0));

  function button(title, x, w, tag, primary, key) {
    v.addSubview(box(x, 13, w, 30, primary ? C('2680EB') : C('3A3A3C'), 5));
    var b = $.NSButton.alloc.initWithFrame(R(x, 13, w, 30));
    b.setBordered(false);
    // JXA 橋接沒有 NSAttributedString 的 initWithString:attributes:，改用 title + font + tint
    b.setTitle($(title));
    b.setFont($.NSFont.systemFontOfSizeWeight(13, primary ? 0.3 : 0));
    b.setContentTintColor(primary ? C('FFFFFF') : C('D6D6D6'));
    b.setTag(tag);
    b.setTarget(handler);
    b.setAction('clicked:');
    if (key) b.setKeyEquivalent($(key));
    v.addSubview(b);
  }

  if (mode === 'ask') {
    button('取消', W - 22 - 104 - 10 - 104 - 10 - 72, 72, 0, false, '\u001b');
    button('關閉鬧鐘', W - 22 - 104 - 10 - 104, 104, 1, isOn, isOn ? '\r' : null);
    button('開啟鬧鐘', W - 22 - 104, 104, 2, !isOn, isOn ? null : '\r');
  } else {
    button('好', W - 22 - 80, 80, 3, true, '\r');
    var timer = $.NSTimer.timerWithTimeIntervalTargetSelectorUserInfoRepeats(3, handler, 'tick:', $(), false);
    $.NSRunLoop.currentRunLoop.addTimerForMode(timer, $.NSModalPanelRunLoopMode);
  }

  win.center;
  $.NSApp.activateIgnoringOtherApps(true);
  win.makeKeyAndOrderFront($());
  $.NSApp.runModalForWindow(win);
  win.orderOut($());
  return choice;
}
